<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\state;


class StateController extends Controller
{
	public function actionList()
	{
		return $this->render ('list');
	}
}
?>