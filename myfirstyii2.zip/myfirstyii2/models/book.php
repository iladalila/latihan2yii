<?php

namespace app\models;

use yii\base\Model;

class book extends Model{

   function attributeLabels()
   {
       return ["bookname" => "Introduction to Yii2 Programming", //Assign Attribute
       "publisher" => "Pearson", //Assign Attribute
       "edition" => "Ninth Edition", //Assign Attribute
       "author" => "Y.Daniel Liang", //Assign Attribute
       "price" => 118.00]; //Assign Attribute

   }
   public function rules()
{
   return [
       [['bookname', 'publisher', 'author', 'price'], 'required']
   ];
}
}
?>
