<?php

use yii\helpers\Html;
use yii\helpers\Url;
use app\models\state; //panggil dari model->book.php(class book) 


$this->title = 'state';
$this->params['breadcrumbs'][] = $this->title;;
$stateModel = new state;

$state = $stateModel->attributeLabels();
?>

<style>
table td, table th{
	text-align:center;
	padding:5px 11px;
}
</style>



<style>
.textbold{
	font-weight: bold}
}
</style>

<ul><strong>Malaysia States</strong>
<table border = "3" cellspacing="0" cellpadding="0">
<tr>
	<TH>State Name</TH>
	<TH>Ibu Negeri</TH>
	<TH>Short Name</TH>
</tr>

<?php 
$num = 0;
$states = new state;
	foreach ($states->getStates() as $state) {
	if($states->getshorts()[$num]=="JHR"){
		$bold = "class='textbold'";
	}else{
		$bold = '';
	}
?>

<tr <?php echo $bold;?>> 
	<td><?php echo $state;?></td>
	<td><?php echo $states->getibus()[$num];?></td>
	<td><?php echo $states->getshorts()[$num];?></td>
</tr>
<?php 
$num++;
}?>
</table></ul>
<hr/>
<ul>*<b>Bold </b> state is the state you're living in.</ul>