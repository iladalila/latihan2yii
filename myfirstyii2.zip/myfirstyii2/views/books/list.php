
<?php

use yii\helpers\Html;
use yii\helpers\Url;
use app\models\book; //panggil dari model->book.php(class book) 


$this->title = 'Book';
$this->params['breadcrumbs'][] = $this->title;;
$bookModel = new book;

$books = $bookModel->attributeLabels();
?>
<div class="site-list">
   <ul>
       <li><?php echo $books['bookname']; ?></li>
       <li><?php echo $books['publisher']; ?></li>
       <li><?php echo $books['edition']; ?></li>
       <li><?php echo $books['author']; ?></li>
       <li><?php echo $books['price']; ?></li>
   </ul>
</div>